export default function Home(){
    return(
        <div className="home">
            <div className="home-container">
            <img className="home-img" src="img/homePage.jpeg" alt="home-page-img" />
            <div className="home_hover">
                <div className="quote"><h1 className="h1class"><br/>WELCOME<br/>TO<br/>RAILWAY</h1>
                    <h1 className="h1class">MANAGEMENT SYSTEM.</h1>
                </div>
            </div>
            </div>
        </div>
    )
}