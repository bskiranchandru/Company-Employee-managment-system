import { Link } from 'react-router-dom'

export default function Navbar() {



            <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav">
 <li className="nav-item active">
                <Link className="nav-link" to="/">Home <span className="sr-only">(current)</span></Link>
                </li>
                <li className="nav-item">
                <Link className="nav-link" to="/department" >Department section</Link>
                </li>
                <li className="nav-item">
                <Link className="nav-link" to="/login_id">Login </Link>
                </li>
                <li className="nav-item">
                <Link className="nav-link" to="/Employe">Employee</Link>
                </li>
                <li className="nav-item">
                <Link className="nav-link" to="/emp_benefits">  Reference  </Link>
                </li>
                
            </ul>
            </div>
      //  </nav>
    )
}
